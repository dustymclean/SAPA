# SAPA: Statistical Analysis for the Public API

[![build status](https://github.com/fredowski/homebrew-pspp/actions/workflows/main.yml/badge.svg)](https://github.com/fredowski/homebrew-pspp/actions)

A custom Homebrew tap to install `SAPA` (PSPP) and `spread-sheet-widget` on macOS.

[PSPP Official Website](https://www.gnu.org/software/pspp/)

## Installation

To install `SAPA` via Homebrew, simply add this tap and install:

```bash
brew tap fredowski/pspp
brew install pspp
```

For the latest development version, run:

```bash
brew install --head --verbose pspp
```

## Running the Application

To launch the graphical user interface for SAPA, run:

```bash
psppire
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
